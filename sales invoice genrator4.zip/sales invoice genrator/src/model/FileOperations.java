package model;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;

public class FileOperations {
    private ArrayList<InvoiceHeader> res;

    public ArrayList<InvoiceHeader> getRes() {
        return res;
    }

    public void setRes(ArrayList<InvoiceHeader> res) {
        this.res = res;
    }

    public ArrayList<InvoiceHeader> readFile(){
        ArrayList<InvoiceHeader> result = new ArrayList<InvoiceHeader>();
        String file = "InvoiceHeader.csv";
        BufferedReader reader = null;
        String line ="";
        try{
            reader = new BufferedReader(new FileReader(file));
            while ((line=reader.readLine())!=null){
                String [] row = line.split(",");
                    int numm = Integer.parseInt(row[0]);
                    String date = row[1];
                    String CustomerName = row[2];
                    InvoiceHeader first = new InvoiceHeader(numm,date,CustomerName);
                    result.add(first);

            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        String file2 = "InvoiceLine.csv";
        BufferedReader reader2 = null;
        String line2 ="";
        try{
            int total=0;
            reader2 = new BufferedReader(new FileReader(file2));
            System.out.println("invoice1Num");
            int i=0;
            int j=0;
            boolean flag = true;
            while ((line2=reader2.readLine())!=null){
                String [] row = line2.split(",");
                for(String index:row){
                    if(i==0 && flag ==true)
                    System.out.println(result.get(j).getInvoiceDate()+" ,"+ result.get(j).getCustomerName());
                    flag =false;
                    if(row[0].equals("1")){
                        String name = row[1];
                        int itemprice = Integer.parseInt(row[2]);
                        int count = Integer.parseInt(row[3]);
                        InvoiceLines y = new InvoiceLines(count,name,itemprice);
                        result.get(j).getInvoicesTable().add(y);

                    System.out.print(index + ", ");
                    int numm = Integer.parseInt(row[2]);
                    total+=numm;
                    }
                    else{
                        i++;
                        if(i==1 && flag == false){
                        System.out.println("invoice2Num");
                        System.out.println(result.get(j).getInvoiceDate()+" ,"+ result.get(j).getCustomerName());
                        flag = true;
                        }
                        System.out.print(index + ", ");
                        int numm = Integer.parseInt(row[2]);
                        total+=numm;
                        String name = row[1];
                        int itemprice = Integer.parseInt(row[2]);
                        int count = Integer.parseInt(row[3]);
                        InvoiceLines y = new InvoiceLines(count,name,itemprice);
                        result.get(j).getInvoicesTable().add(y);
                    }
                }
                result.get(j).setTotal(total);
                j++;

                System.out.println();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            return result;
        }


    }

    void writeFile(ArrayList<InvoiceHeader> e){
    }
    /*public static void main(String[] args){
        new FileOperations();


    }*/

}
