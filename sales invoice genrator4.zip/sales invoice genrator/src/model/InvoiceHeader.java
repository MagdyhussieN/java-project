package model;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class InvoiceHeader{
    private int invoiceNum;
    private String invoiceDate;
    private String customerName;
    private ArrayList<InvoiceLines> InvoicesTable;
    private int total;



    public InvoiceHeader(String invoiceDate, String customerName) {
        this.customerName=customerName;
        this.invoiceDate=invoiceDate;

    }
    public InvoiceHeader(int invoiceNum,String invoiceDate,String customerName) {
        this.customerName=customerName;
        this.invoiceDate=invoiceDate;
        this.invoiceNum=invoiceNum;
        InvoicesTable = new ArrayList<InvoiceLines>();

    }
    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }


    public void setInvoiceNum(int invoiceNum) {
        this.invoiceNum = invoiceNum;
    }

    public void setInvoiceDate(String invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public void setInvoicesTable(ArrayList<InvoiceLines> invoicesTable) {
        InvoicesTable = invoicesTable;
    }

    public int getInvoiceNum() {
        return invoiceNum;
    }

    public String getInvoiceDate() {
        return invoiceDate;
    }

    public String getCustomerName() {
        return customerName;
    }

    public ArrayList<InvoiceLines> getInvoicesTable() {
        return InvoicesTable;
    }

    public void deleteinvoice(InvoiceLines x) {
        for (int i = 0; i < InvoicesTable.size(); i++) {
            if (x.getCount() == InvoicesTable.get(i).getCount()) {
                InvoicesTable.remove(i);
            }
        }
    }

    public void createinvoice(InvoiceLines x) {
        this.InvoicesTable.add(x);
    }
}
