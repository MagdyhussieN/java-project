package model;

import java.time.LocalDate;
import java.util.ArrayList;

public class InvoiceLines {
    private int Count;
    private String itemName;
    private int itemPrice;


    public InvoiceLines(int count,String itemName,int itemPrice) {
        this.Count = count;
        this.itemName=itemName;
        this.itemPrice=itemPrice;
    }

    public int getCount() {
        return Count;
    }

    public String getItemName() {
        return itemName;
    }

    public int getItemPrice() {
        return itemPrice;
    }

    public void setCount(int count) {
        Count = count;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public void setItemPrice(int itemPrice) {
        this.itemPrice = itemPrice;
    }
}