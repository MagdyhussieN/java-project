package view;

import javax.swing.*;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import model.FileOperations;
import model.InvoiceHeader;

public class view extends JFrame implements ActionListener {
    ArrayList<JButton> table1 = new ArrayList<>();
    JPanel left;
    JMenuItem LoadFile;
    JMenuItem SaveFile;
    ArrayList<InvoiceHeader> result;
    JTable jt;
    JTable jt2;
    DefaultTableModel tableModel;
    JButton delete;
    JButton create;
    JButton cancel;
    JButton save;
    public view(){
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(1400,900);
        this.setLayout(new BorderLayout());
        this.setLocationRelativeTo(null);
        left = new JPanel();
        JPanel right = new JPanel();
        JPanel x = new JPanel();
        x.setSize(1400,800);
        this.add(x);
        x.setLayout(new GridLayout(1,2));
        x.add(left);
        x.add(right);
        left.setBounds(20,30,650,800);
        left.setPreferredSize(new Dimension(650,800));
        right.setBounds(800,30,650,800);
        right.setPreferredSize(new Dimension(650,800));
        left.setLayout(new BorderLayout());
        createmenubar();
        result = new ArrayList<InvoiceHeader>();

        //res = copyinto2darray();
        createinvoicetable(left,result);
        createleftbutton(left);
        createstyleright(right);
        this.setVisible(true);

    }
    public void createinvoicetable(JPanel left,ArrayList<InvoiceHeader> result){
        String text = "<html>"  + "    " + "Invoices Table";
        JLabel tt = new JLabel();
        tt.setText(text);
        left.add(tt,BorderLayout.NORTH);
        // make table to get data from csv file
        String column[]={"NO.","Date","Customer","Total"};
        DefaultTableModel tableModel = new DefaultTableModel(column,0);
        jt = new JTable(tableModel);
        FileOperations x2 = new FileOperations();
        result=x2.readFile();
        fillfirsttable(jt,result);


        //JTable jt=new JTable(,column);
        left.add(jt);
        jt.setPreferredSize(new Dimension(500,300));
        JScrollPane xx = new JScrollPane();
        xx.getViewport().add(jt);
        left.add(xx);
        jt.setBounds(20,50,500,200);
        jt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void jTable1MouseClicked(java.awt.event.MouseEvent ew) {
                DefaultTableModel tblmodel2 = (DefaultTableModel) jt.getModel();
                String tblDate = (String) tblmodel2.getValueAt(jt.getSelectedRow(), 1);
                String tblName = (String) tblmodel2.getValueAt(jt.getSelectedRow(), 2);
                System.out.println(tblDate + " " + tblName);
                addintosecondtable(tableModel, tblName);
            }
        });
    }
    public void fillfirsttable(JTable jt,ArrayList<InvoiceHeader> result){
        for(int i=0;i<result.size();i++){
            int num = result.get(i).getInvoiceNum();
            String date = result.get(i).getInvoiceDate();
            String Customer = result.get(i).getCustomerName();
            int total = result.get(i).getTotal();
            Object [] fill = {num,date,Customer,total};
            tableModel.addRow(fill);
        }
    }

    void addintosecondtable(DefaultTableModel tabelmodel,String tblName){
        for(int i=0;i<this.result.size();i++){
            if(this.result.get(i).getCustomerName().equals(tblName)) {
                int total = 0;
                for (int j = 0; j < this.result.get(i).getInvoicesTable().size(); j++) {
                    int j2 = j + 1;
                    String name = this.result.get(i).getInvoicesTable().get(j).getItemName();
                    int itemPrice = this.result.get(i).getInvoicesTable().get(j).getItemPrice();
                    int count = this.result.get(i).getInvoicesTable().get(j).getCount();
                    total += (this.result.get(i).getInvoicesTable().get(j).getItemPrice() * count);
                    Object[] row = {j2, name, itemPrice, count, total};
                    tableModel.addRow(row);
                }
            }
        }
    }
    public void createleftbutton(JPanel left){
        JPanel down = new JPanel();
        create = new JButton("Create New Invoice");create.addActionListener(this);
        delete = new JButton("Delete Invoice");delete.addActionListener(this);
        down.setLayout(new GridLayout(1,2));
        down.add(create);
        down.add(delete);
        down.setVisible(true);
        left.add(down,BorderLayout.SOUTH);
        down.setBounds(20,800,100,30);
    }
    public void createmenubar(){
        JMenuBar mb = new JMenuBar();
        this.add(mb,BorderLayout.NORTH);
        JMenu file = new JMenu("file");
        LoadFile = new JMenuItem("load file");LoadFile.addActionListener(this);
        SaveFile = new JMenuItem("save file");SaveFile.addActionListener(this);
        file.add(LoadFile);
        file.add(SaveFile);
        mb.setLayout(new BorderLayout());
        mb.add(file,BorderLayout.WEST);
        // add action listener
    }
    public void createstyleright(JPanel right){
        right.setLayout(new GridLayout(4,1));
        JPanel first = new JPanel();
        first.setLayout(new GridLayout(4,1));
        first.setPreferredSize(new Dimension(500,300));
        JLabel first11 = new JLabel();
        first11.setLayout(new GridLayout(1,2));
        JLabel tt = new JLabel("<html>" + "<br>" + "invoice number");
        JLabel first1=new JLabel("<html>" + "<br>" + "<br>"+"    " +"invoice date");
        JTextField date = new JTextField(15);
        first.add(tt);
        first11.add(first1);
        first11.add(date);
        first.add(first11);
        right.add(first);
        tt.setBounds(820,30,20,20);
        first.setBounds(820,40,100,20);
        JLabel first22 = new JLabel();
        first22.setLayout(new GridLayout(1,2));
        first22.setPreferredSize(new Dimension(200,50));
        JLabel first2=new JLabel("<html>" + "<br>" + "<br>"+"    " +"Customer name");
        JTextField CustomerName = new JTextField(15);
        first22.add(first2);first22.add(CustomerName);
        first.add(first22);
        first.add(new JLabel("Invoice Total"));

        // add text invoice item
        right.add(new JLabel("Invoice item"));
        FileOperations x2 = new FileOperations();
        result=x2.readFile();

        // add second table item
        String column[]={"NO.","Item name","Item price","Count","Total"};
        tableModel = new DefaultTableModel(column,0);
        jt2 = new JTable(tableModel);
        jt.setPreferredSize(new Dimension(500,300));
        JScrollPane xx = new JScrollPane();
        xx.getViewport().add(jt2);
        right.add(xx);

        // add buttons to right frame
        JPanel down2 = new JPanel();
        save = new JButton("Save");save.addActionListener(this);
        cancel = new JButton("Cancel");cancel.addActionListener(this);
        down2.setLayout(new GridLayout(1,2));
        down2.add(create);
        down2.add(delete);
        down2.setVisible(true);
        right.add(down2);
        down2.setPreferredSize(new Dimension(400,100));






    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==LoadFile){
            try {
                importfile();
            } catch (FileNotFoundException ex) {
                ex.printStackTrace();
            }
        }
        if(e.getSource()==SaveFile){
            JFileChooser fc = new JFileChooser();
            fc.setCurrentDirectory(new File(""));
            int response = fc.showSaveDialog(null);
            if(response==JFileChooser.APPROVE_OPTION){
                File file = new File(fc.getSelectedFile().getAbsolutePath());
                System.out.print("file");
            }
        }
        if(e.getSource()==delete){
            DefaultTableModel temp = (DefaultTableModel) jt.getModel();
            if(jt.getSelectedRowCount()==1){
                temp.removeRow(jt.getSelectedRow());
            }
            else {
                if (jt.getSelectedRowCount() == 0) {

                    JOptionPane.showMessageDialog(this, "table is empty");
                } else {
                    JOptionPane.showMessageDialog(this, "please select single row to delete ");

                }
            }
        }
        if(e.getSource()==create){
            createbuttonwork();
        }
        if(e.getSource()==save){
            fillfirsttable(jt,result);
        }
    }
    public void createbuttonwork(){
        JFrame x = new JFrame();
        x.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        x.setSize(500,500);
        x.setLayout(new BorderLayout());
        x.setLocationRelativeTo(null);
        JPanel are = new JPanel();
        JPanel tex = new JPanel();
        are.setLayout(new GridLayout(2,2));
        JTextField Name = new JTextField("Customer name");
        JTextField Date = new JTextField("date");
        JLabel text1 = new JLabel("Customer name");
        JLabel text2 = new JLabel("Date");
        are.add(text1);
        are.add(Name);
        are.add(text2);
        are.add(Date);
        JButton done = new JButton("Done");
        x.add(are,BorderLayout.CENTER);
        x.add(done, BorderLayout.SOUTH);
        if(Name.getText().equals("Customer name") || Date.getText().equals("Date")){
            JOptionPane.showMessageDialog(x,"please fill the data");
        }


            done.addActionListener(e -> {
                this.result.add(new InvoiceHeader(Date.getText(), Name.getText()));
                Object[] data = {result.size(), Date.getText(), Name.getText()};
                DefaultTableModel tm = (DefaultTableModel) jt.getModel();
                tm.addRow(data);
                x.dispose();
            });

        x.setVisible(true);
    }

    public static void main(String[] args) {
        new view();
    }


    private void importfile() throws FileNotFoundException{
        JFileChooser fc = new JFileChooser();
        FileInputStream fis = null;
        if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            String path = fc.getSelectedFile().getPath();
            File file = new File(fc.getSelectedFile().getAbsolutePath());
            ArrayList<InvoiceHeader> res = new ArrayList<InvoiceHeader>();
          //  res=copyinto2darray(file);
            createinvoicetable(left,res);
        }


    }
}
