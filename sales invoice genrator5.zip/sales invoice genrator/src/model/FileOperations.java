package model;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;

public class FileOperations {
    private ArrayList<InvoiceHeader> res;
    public FileOperations(){
        res = new ArrayList<InvoiceHeader>();
    }

    public ArrayList<InvoiceHeader> getRes() {
        return res;
    }

    public void setRes(ArrayList<InvoiceHeader> res) {
        this.res = res;
    }

    public static ArrayList<InvoiceHeader> readFile(){
        ArrayList<InvoiceHeader> result = new ArrayList<InvoiceHeader>();
        String file = "InvoiceHeader.csv";
        BufferedReader reader = null;
        String line ="";
        try{
            reader = new BufferedReader(new FileReader(file));
            while ((line=reader.readLine())!=null){
                String [] row = line.split(",");
                    int numm = Integer.parseInt(row[0]);
                    String date = row[1];
                    String CustomerName = row[2];
                    InvoiceHeader first = new InvoiceHeader(numm,date,CustomerName);
                    result.add(first);


            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        String file2 = "InvoiceLine.csv";
        BufferedReader reader2 = null;
        String line2 ="";
        try{
            int total=0;
            reader2 = new BufferedReader(new FileReader(file2));
            System.out.println("invoice1Num");
            int i=0;
            int j=0;
            boolean flag = true;
            while ((line2=reader2.readLine())!=null){
                String [] row = line2.split(",");
                String name="";
                int itemprice = 0;
                int count =0;
                for(String index:row){
                    if(i==0 && flag ==true){
                    System.out.println(result.get(j).getInvoiceDate()+" ,"+ result.get(j).getCustomerName());
                    flag =false;}
                    if(Integer.parseInt(row[0])==1){
                        name = row[1];
                        itemprice = Integer.parseInt(row[2]);
                        count = Integer.parseInt(row[3]);
                    System.out.print(index + ", ");
                    }
                    if(Integer.parseInt(row[0])==2){
                        i=i+1;
                        if(i==1 && flag == false){
                        System.out.println("invoice2Num");
                        System.out.println(result.get(1).getInvoiceDate()+" ,"+ result.get(1).getCustomerName());
                        flag = true;
                        }
                        System.out.print(index + ", ");
                        name = row[1];
                        itemprice = Integer.parseInt(row[2]);
                        count = Integer.parseInt(row[3]);
                    }
                }
                int numm = Integer.parseInt(row[2]);
                total+=numm;
                InvoiceLines y = new InvoiceLines(count,name,itemprice);
                if(Integer.parseInt(row[0])==1){
                result.get(j).getInvoicesTable().add(y);
                result.get(j).setTotal(total);}
                else {
                    j++;
                    
                }
                System.out.println();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            return result;
        }


    }

    void writeFile(ArrayList<InvoiceHeader> e){
    }
    public static void main(String[] args){
        new FileOperations();
        ArrayList<InvoiceHeader> res = new ArrayList<InvoiceHeader>();
        res = readFile();



    }

}
